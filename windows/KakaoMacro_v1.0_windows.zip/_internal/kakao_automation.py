import logging
import os
import platform
import random
import subprocess
import sys
import time
from enum import Enum
from io import BytesIO

import pyautogui
import pyperclip
from PIL import Image
from pynput.keyboard import Controller, Key
from PyQt5.QtWidgets import QApplication, QMessageBox

if platform.system() == 'Darwin':
    import Quartz
    from AppKit import NSApplicationActivateIgnoringOtherApps, NSWorkspace

class MessageType(Enum):
    TEXT = "text"
    IMAGE = "image"

class Message:
    def __init__(self, type: MessageType, content: str):
        self.type = type
        self.content = content

class KakaoAutomation:
    def __init__(self, ui):
        self.ui = ui
        self.keyboard = Controller()
        self.is_running = False
        self.chat_windows = []
        
        try:
            # 초기 권한 확인
            if not self.check_permissions():
                if hasattr(self.ui, 'log_output'):
                    self.ui.log("필요한 권한이 부족합니다. 권한을 설정해주세요.")
        except Exception as e:
            logging.error(f"권한 확인 중 오류 발생: {str(e)}")

    def check_permissions(self):
        """권한 확인 및 안내"""
        missing_permissions = []
        permission_status = {}
        
        def safe_log(message):
            """안전하게 로그를 출력하는 헬퍼 함수"""
            if hasattr(self.ui, 'log_output'):
                self.ui.log(message)
            logging.info(message)
        
        if platform.system() == "Darwin":  # macOS
            # 화면 기록 권한 확인
            try:
                screen = pyautogui.screenshot()
                if screen is None or screen.size[0] == 0 or screen.size[1] == 0:
                    missing_permissions.append("화면 기록")
                    permission_status["화면 기록"] = False
                    safe_log("❌ 화면 기록 권한이 없습니다.")
                else:
                    try:
                        screen.getpixel((0, 0))
                        permission_status["화면 기록"] = True
                        safe_log("✅ 화면 기록 권한이 확인되었습니다.")
                    except Exception:
                        missing_permissions.append("화면 기록")
                        permission_status["화면 기록"] = False
                        safe_log("❌ 화면 기록 권한이 없습니다.")
            except Exception as e:
                logging.error(f"화면 기록 권한 확인 중 오류: {str(e)}")
                missing_permissions.append("화면 기록")
                permission_status["화면 기록"] = False
                safe_log("❌ 화면 기록 권한 확인 중 오류가 발생했습니다.")

            # 손쉬운 사용 권한 확인
            try:
                script = '''
                    tell application "System Events"
                        tell process "KakaoTalk"
                            return name
                        end tell
                    end tell
                '''
                result = subprocess.run(['osascript', '-e', script],
                                     capture_output=True, text=True)
                if result.returncode != 0 or "KakaoTalk" not in result.stdout :
                    missing_permissions.append("손쉬운 사용")
                    permission_status["손쉬운 사용"] = False
                    safe_log("❌ 손쉬운 사용 권한이 없습니다.")
                else:
                    permission_status["손쉬운 사용"] = True
                    safe_log("✅ 손쉬운 사용 권한이 확인되었습니다.")
            except Exception as e:
                logging.error(f"손쉬운 사용 권한 확인 중 오류: {str(e)}")
                missing_permissions.append("손쉬운 사용")
                permission_status["손쉬운 사용"] = False
                safe_log("❌ 손쉬운 사용 권한 확인 중 오류가 발생했습니다.")

        else:  # Windows
            try:
                # Windows에서는 화면 캡처 권한 확인
                screen = pyautogui.screenshot()
                if screen is None or screen.size[0] == 0 or screen.size[1] == 0:
                    missing_permissions.append("화면 캡처")
                    permission_status["화면 캡처"] = False
                    safe_log("❌ 화면 캡처 권한이 없습니다.")
                else:
                    try:
                        screen.getpixel((0, 0))
                        permission_status["화면 캡처"] = True
                        safe_log("✅ 화면 캡처 권한이 확인되었습니다.")
                    except Exception:
                        missing_permissions.append("화면 캡처")
                        permission_status["화면 캡처"] = False
                        safe_log("❌ 화면 캡처 권한이 없습니다.")
            except Exception as e:
                logging.error(f"화면 캡처 권한 확인 중 오류: {str(e)}")
                missing_permissions.append("화면 캡처")
                permission_status["화면 캡처"] = False
                safe_log("❌ 화면 캡처 권한 확인 중 오류가 발생했습니다.")

        if missing_permissions:
            self.show_permission_guide(missing_permissions, permission_status, result)
            return False
            
        logging.info("모든 필요 권한이 확인되었습니다.")
        safe_log("✅ 모든 필요 권한이 확인되었습니다.")
        return True

    def show_permission_guide(self, missing_permissions, permission_status, result):
        """권한 설정 가이드 표시"""
        guide = QMessageBox()
        guide.setIcon(QMessageBox.Warning)
        guide.setWindowTitle("권한 설정 필요")
        
        # 현재 권한 상태 메시지 생성
        status_msg = "현재 권한 상태:\n"
        for perm, status in permission_status.items():
            status_icon = "✅" if status else "❌"
            status_msg += f"- {perm}: {status_icon}\n"
        
        guide.setText(status_msg + f"\nlog - {result.returncode} / {result.stderr}")
        
        if platform.system() == "Darwin":  # macOS
            # 설정 방법 안내
            guide.setInformativeText(
                "필요한 권한을 설정하려면 '설정하기' 버튼을 클릭하세요.\n"
                "설정 후에는 앱을 완전히 종료했다가 다시 실행해주세요."
            )
            
            # 버튼 추가
            guide.setStandardButtons(QMessageBox.Ok)
            guide.button(QMessageBox.Ok).setText("설정하기")

            if guide.exec_() == QMessageBox.Ok:
                # 화면 기록 권한 설정 페이지 열기
                if "화면 기록" in missing_permissions:
                    subprocess.run([
                        'open',
                        'x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture'
                    ])
                # 손쉬운 사용 권한 설정 페이지 열기
                if "손쉬운 사용" in missing_permissions:
                    subprocess.run([
                        'open',
                        'x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility'
                    ])
                time.sleep(0.5)
                sys.exit(1)
        else:  # Windows
            guide.setInformativeText(
                "Windows에서는 별도의 권한 설정이 필요하지 않습니다.\n"
                "문제가 지속되면 관리자 권한으로 프로그램 보세요."
            )
            guide.setStandardButtons(QMessageBox.Ok)
            guide.button(QMessageBox.Ok).setText("확인")
            guide.exec_()

    def open_kakaotalk(self):
        """카카오톡 실행"""
        if platform.system() == "Windows":
            # Windows의 일반적인 카카오톡 설치 경로들
            possible_paths = [
                os.path.expandvars("%LOCALAPPDATA%\\Kakao\\KakaoTalk\\KakaoTalk.exe"),
                "C:\\Program Files\\Kakao\\KakaoTalk\\KakaoTalk.exe",
                "C:\\Program Files (x86)\\Kakao\\KakaoTalk\\KakaoTalk.exe"
            ]
            
            kakao_path = None
            for path in possible_paths:
                if os.path.exists(path):
                    kakao_path = path
                    break
            
            if kakao_path:
                try:
                    subprocess.Popen([kakao_path])
                    self.ui.log("카카오톡을 실행했습니다.")
                except Exception as e:
                    self.ui.log(f"카카오톡 실행 중 오류 발생: {str(e)}")
            else:
                self.ui.log("카카오톡 실행 파일을 찾을 수 없습니다. 카카오톡이 설치되어 있는지 확인해주세요.")
                
        elif platform.system() == "Darwin":
            subprocess.Popen(["open", "-a", "KakaoTalk"])
            self.ui.log("카카오톡을 실행했습니다.")

    def get_kakaotalk_windows_info(self):
        """대화창 정보 가져오기"""
        if platform.system() == "Windows":
            try:
                import psutil
                import pygetwindow as gw
                import win32gui
                import win32process
                
                windows = gw.getWindowsWithTitle('')
                titles = []
                self.chat_windows = []
                
                system_windows = [
                    "카카오톡",
                    "KakaoTalk",
                    "카카오톡 설정",
                    "KakaoTalk Settings",
                    "카카오톡 업데이트",
                    "카카오톡 로그인",
                    "카카오톡 자동메시지",
                    "채팅방 목록",
                    "친구 목록",
                    "더보기",
                    "Window",
                    ""
                ]
                
                for win in windows:
                    if not win.title or win.title in system_windows:
                        continue
                    
                    try:
                        hwnd = win._hWnd
                        _, pid = win32process.GetWindowThreadProcessId(hwnd)
                        process = psutil.Process(pid)
                        
                        if "kakaotalk" in process.name().lower() and win.title is not None and win.title != '':
                            self.chat_windows.append(win)
                            titles.append(win.title)
                    except Exception:
                        continue
                    
                return len(self.chat_windows), titles
                
            except Exception as e:
                self.ui.log(f"대화창 정보를 가져오는 중 오류 발생: {str(e)}")
                return 0, []
                
        elif platform.system() == "Darwin":
            options = Quartz.kCGWindowListOptionOnScreenOnly | Quartz.kCGWindowListExcludeDesktopElements
            window_list = Quartz.CGWindowListCopyWindowInfo(options, Quartz.kCGNullWindowID)
            
            windows = []
            titles = []
            for win in window_list:
                owner = win.get('kCGWindowOwnerName', '')
                title = win.get('kCGWindowName', '')
                layer = win.get('kCGWindowLayer', 0)
                
                if owner == '카카오톡' and layer == 0 and title != '카카오톡' and title != 'Window':
                    windows.append(win)
                    titles.append(title)
                    
            return len(windows), titles
            
        return 0, []

    def focus_first_window(self):
        """첫 번째 창 활성화"""
        if platform.system() == "Windows":
            try:
                if self.chat_windows:
                    self.chat_windows[0].activate()
                    time.sleep(0.5)
                else:
                    self.ui.log("활성화할 대화창을 찾을 수 없습니다.")
                    
            except Exception as e:
                self.ui.log(f"첫 창 활성화 오류: {str(e)}")
                
        elif platform.system() == "Darwin":
            try:
                script = '''
                tell application "KakaoTalk" to activate
                '''
                subprocess.run(['osascript', '-e', script], check=True)
                time.sleep(0.5)
                
                active_window = self.get_active_window()
                if active_window and active_window.get('kCGWindowName') == '카카오톡':
                    self.focus_next_window()
                
            except Exception as e:
                self.ui.log(f"첫 창 활성화 오류: {e}")

    def get_active_window(self):
        """현재 활성화된 창 정보 가져오기"""
        options = Quartz.kCGWindowListOptionOnScreenOnly | Quartz.kCGWindowListExcludeDesktopElements
        window_list = Quartz.CGWindowListCopyWindowInfo(options, Quartz.kCGNullWindowID)
        
        for win in window_list:
            if win.get('kCGWindowLayer', 0) == 0 and win.get('kCGWindowOwnerName', '') == '카카오톡':
                return win
        return None

    def focus_next_window(self):
        """다음 창으로 전환"""
        if platform.system() == "Windows":
            try:
                import pygetwindow as gw
                
                if not self.chat_windows:
                    self.ui.log("전환 가능한 대화창이 없습니다.")
                    return
                
                # 현재 활성화된 창의 인덱스 찾기
                active_window =gw.getActiveWindow()
                if not active_window:
                    self.ui.log("현재 활성화된 창을 찾을 수 없습니다.")
                    return
                
                current_index = -1
                for i, win in enumerate(self.chat_windows):
                    if win._hWnd == active_window._hWnd:
                        current_index = i
                        break
                
                # 다음 창 선택 (마지막 창이면 첫 번째 창으로)
                next_index = (current_index + 1) % len(self.chat_windows)
                next_window = self.chat_windows[next_index]
                
                # 다음 창 활성화
                try:
                    self.ui.log(f"다음 대화창으로 전환: {next_window.title}")
                    next_window.activate()
                    time.sleep(0.5)
                except Exception as e:
                    self.ui.log(f"창 전환 중 오류 발생: {str(e)}")
                
            except Exception as e:
                self.ui.log(f"창 전환 오류: {str(e)}")
                
        elif platform.system() == "Darwin":
            try:
                script = '''
                tell application "System Events"
                    tell process "KakaoTalk"
                        keystroke "`" using command down
                    end tell
                end tell
                '''
                subprocess.run(['osascript', '-e', script], check=True)
                time.sleep(0.5)
                active_window = self.get_active_window()
                self.ui.log(f"현재 활성화된 창: {active_window.get('kCGWindowName')}")
                if active_window and active_window.get('kCGWindowName') == '카카오톡':
                    self.focus_next_window()

            except Exception as e:
                self.ui.log(f"창 전환 오류: {e}")

    def copy_image_to_clipboard(self, image_path):
        """이미지를 클립보드에 복사"""
        if platform.system() == "Windows":
            try:
                import win32clipboard
                from PIL import Image

                # 이미지 열기
                image = Image.open(image_path)
                
                # PNG 형식으로 변환
                output = BytesIO()
                image.convert('RGB').save(output, 'BMP')
                data = output.getvalue()[14:]  # BMP 헤더 제거
                output.close()
                
                # 클립보드에 복사
                win32clipboard.OpenClipboard()
                win32clipboard.EmptyClipboard()
                win32clipboard.SetClipboardData(win32clipboard.CF_DIB, data)
                win32clipboard.CloseClipboard()
                
                self.ui.log("이미지를 클립보드에 복사했습니다.")
            except Exception as e:
                self.ui.log(f"이미지 복사 중 오류 발생: {str(e)}")
                # 오류 발생 시 기존 방식으로 폴백
                pyperclip.copy(image_path)
                
        elif platform.system() == "Darwin":
            subprocess.run(['osascript', '-e', f'''
                set the clipboard to (read (POSIX file "{image_path}") as JPEG picture)
            '''])

    def paste_image(self):
        """이미지 붙여넣기"""
        if platform.system() == "Windows":
            pyautogui.hotkey('ctrl', 'v')
            time.sleep(0.5)  # 붙여넣기 후 약간의 대기 시간 추가
            self.keyboard.press(Key.enter)
            self.keyboard.release(Key.enter)
        else:  # Darwin
            pyautogui.hotkey('command', 'v')
            time.sleep(0.5)
            self.keyboard.press(Key.enter)
            self.keyboard.release(Key.enter)

    def write_korean(self, text):
        """한글 입력 처리"""
        # 클립보드에 복사
        original_clipboard = pyperclip.paste()  # 현재 클립보드 내용 저장
        pyperclip.copy(text)
        time.sleep(0.2)
        
        # 붙여넣기 실행
        if platform.system() == "Darwin":
            with self.keyboard.pressed(Key.cmd):
                self.keyboard.press('v')
                self.keyboard.release('v')
        else:
            with self.keyboard.pressed(Key.ctrl):
                self.keyboard.press('v')
                self.keyboard.release('v')
        
        time.sleep(0.2)
        
        # 전송 버튼 누르기 (Enter 키 사용)
        self.keyboard.press(Key.enter)
        self.keyboard.release(Key.enter)
        
        time.sleep(0.2)
        pyperclip.copy(original_clipboard)  # 원래 클립보드 내용 복원

    def send_messages(self, messages):
        """메시지 전송"""
        count, _ = self.get_kakaotalk_windows_info()
        if count == 0:
            QMessageBox.warning(self.ui, "알림", "열려있는 대화창이 없습니다.\n보내려는 대화창을 모두 열고 수행해주세요.")
            return

        self.is_running = True
        self.ui.progress_bar.setMaximum(count)
        self.ui.progress_bar.setValue(0)
        
        try:
            self.focus_first_window()
            # time.sleep(1)
            
            for i in range(count):
                if not self.is_running:
                    break
                    
                self.ui.progress_bar.setValue(i + 1)
                
                for message in messages:
                    if not message:
                        continue
                        
                    try:
                        if message.type == MessageType.TEXT:
                            self.write_korean(message.content)
                        else:  # MessageType.IMAGE
                            self.copy_image_to_clipboard(message.content)
                            self.paste_image()
                            
                        # 랜덤 딜레이 추가 (0.5~1.5초)
                        time.sleep(random.uniform(0.5, 1.5))
                        
                    except Exception as e:
                        self.ui.log(f"메시지 전송 중 오류: {str(e)}")
                
                if i < count - 1:  # 마지막 창이 아닌 경우에만 다음 창으로 이동
                    self.focus_next_window()
                    # time.sleep(1)
                else:
                    self.ui.log("전송 완료")
                    
        except Exception as e:
            self.ui.log(f"메시지 전송 중 오류 발생: {str(e)}")
            
        finally:
            self.is_running = False
            self.ui.progress_bar.setValue(0)
            self.ui.stop_button.setEnabled(False)

    def stop_sending(self):
        """메시지 전송 중단"""
        self.is_running = False
  