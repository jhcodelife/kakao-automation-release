"""
카카오톡 자동화 프로그램 설정 파일
"""

# 프로그램 정보
PROGRAM_INFO = {
    "version": "1.0.0",
    "developer": "jh.codelife@gmail.com",
    "description": "기능 추가나, 버그 등 문의사항은 이메일로 연락주세요.",
}

# 프로그램 정보 포맷
def get_program_info():
    """프로그램 정보 문자열 반환"""
    return (
        f"v{PROGRAM_INFO['version']} | "
        f"{PROGRAM_INFO['developer']}\n"
        f"{PROGRAM_INFO['description']}"
    ) 